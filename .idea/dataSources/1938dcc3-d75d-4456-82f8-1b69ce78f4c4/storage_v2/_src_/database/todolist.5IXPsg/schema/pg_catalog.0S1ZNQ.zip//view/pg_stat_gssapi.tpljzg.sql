create view pg_stat_gssapi(pid, gss_authenticated, principal, encrypted, credentials_delegated) as
SELECT pid,
       gss_auth       AS gss_authenticated,
       gss_princ      AS principal,
       gss_enc        AS encrypted,
       gss_delegation AS credentials_delegated
FROM pg_stat_get_activity(NULL::integer) s(datid, pid, usesysid, application_name, state, query, wait_event_type,
                                           wait_event, xact_start, query_start, backend_start, state_change,
                                           client_addr, client_hostname, client_port, backend_xid, backend_xmin,
                                           backend_type, ssl, sslversion, sslcipher, sslbits, ssl_client_dn,
                                           ssl_client_serial, ssl_issuer_dn, gss_auth, gss_princ, gss_enc,
                                           gss_delegation, leader_pid, query_id)
WHERE client_port IS NOT NULL;

alter table pg_stat_gssapi
    owner to postgres;

grant select on pg_stat_gssapi to public;

